![Task2_Screenshot1](https://github.com/jiaqiyu1/Property_Analysis/assets/84236678/af3b245e-e47c-47f3-b117-aa60e2b436c8)
![Task2_Screenshot2](https://github.com/jiaqiyu1/Property_Analysis/assets/84236678/078553c6-8404-4f73-b443-bf13a4db7be8)
